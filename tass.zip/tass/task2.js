let name1 = "pavel";
let name2 = "olya";
let equal = "hello " + name1 + " " + name2;//об'єднуємо
console.log(equal);//виводимо в консоль

let greeting = `Привіт, ${name1} та ${name2}!`;
console.log(greeting);